//
//  Bridge.h
//  SwiftRecorder
//
//  Created by iOS on 2018/9/25.
//  Copyright © 2018 AidaHe. All rights reserved.
//

#ifndef Bridge_h
#define Bridge_h

#import "ConvertMp3.h"
#import "AmrCodec.h"

#endif /* Bridge_h */
