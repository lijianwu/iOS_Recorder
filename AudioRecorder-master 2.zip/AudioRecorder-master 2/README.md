# AudioRecorder
A Simple audio recorder and player written in swift using default swift classes.
