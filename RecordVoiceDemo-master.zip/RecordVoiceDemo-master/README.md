# RecordVoiceDemo
录音小demo
详情请移步简书 [iOS中录音功能](https://www.jianshu.com/p/c1bdab0ddf59).